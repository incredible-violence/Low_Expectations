package mesken.prove_05;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private EditText book;
    private EditText chapter;
    private EditText verses;
    private Button submit;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        addListenerOnButton();
    }

    public void addListenerOnButton() {
        submit = (Button) findViewById(R.id.submit);

        submit.setOnClickListener(new View.OnClickListener() {

            public void onClick(View view) {

                book    = (EditText) findViewById(R.id.book);
                chapter = (EditText) findViewById(R.id.chapter);
                verses  = (EditText) findViewById(R.id.verses);

                String reference = book.getText().toString()
                        + " "
                        + chapter.getText().toString()
                        + " : "
                        + verses.getText().toString();
                Log.d("TAG", "About to create intent with " + reference);
                Intent myIntent = new Intent(view.getContext(), Display.class);
                myIntent.putExtra("reference", reference);
                startActivity(myIntent);
            }
        });
    }
}
