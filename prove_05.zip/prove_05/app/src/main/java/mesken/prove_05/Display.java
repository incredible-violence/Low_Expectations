package mesken.prove_05;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import static mesken.prove_05.R.id.reference;

/**
 * Created by lj on 5/20/17.
 */

public class Display extends Activity {
    TextView myTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.display);

        myTextView = (TextView) findViewById(reference);
        myTextView.setText(getIntent().getStringExtra("reference"));
        Log.d("TAG", "Recieved reference: " + getIntent().getStringExtra("reference"));
    }
}
